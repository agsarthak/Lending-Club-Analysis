package com.neu.assign2;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ClassificationController {
	private static final Logger logger = LoggerFactory.getLogger(ClassificationController.class);

	@RequestMapping(value = "/classification.htm", method = RequestMethod.GET)
	public String getclassification() {
		logger.info("Welcome Classification!");
		return "Classification";
	}

	@RequestMapping(value = "/classification.htm", method = RequestMethod.POST)
	public ModelAndView postclassification(HttpServletRequest request, HttpServletResponse response) {
		logger.info("Classification POST method!");
		String dti_ratio = request.getParameter("dti_ratio");
		String fico = request.getParameter("fico");
		String loan_amnt = request.getParameter("loan_amnt");
		String emp_length = request.getParameter("emp_length");
		String policy_code = request.getParameter("policy_code");
		JSONObject obj = new JSONObject();
		JSONObject inputs = new JSONObject();
		JSONObject input1 = new JSONObject();
		String[] columns = { "Column 0","dti_ratio", "emp_length","fico_score", "state","policy_code","loan_amnt","zip_code",
		        "accepted_status" };
		String[][] values = { { "0", dti_ratio, emp_length, fico,"", policy_code, loan_amnt,"", "" } };
		input1.put("ColumnNames", columns);
		input1.put("Values", values);
		inputs.put("input1", input1);
		obj.put("Inputs", inputs);
		String json = obj.toString();
		System.out.println(json);
		ClassficationOutput cv = svmClassification(json);
		ModelAndView mv = new ModelAndView("ClassificationOutput");
		mv.addObject("classificationOutput", cv);
		return mv;
	}

	public static ClassficationOutput svmClassification(String jsonBody) {

		HttpPost post;
		HttpClient client;
		StringEntity entity;

		try {
			// create HttpPost and HttpClient object
			post = new HttpPost(
					"https://ussouthcentral.services.azureml.net/workspaces/90cebf512f1e4f558e795cd981b31238/services/97ef06f2460e4d368a18f41fd4fa81e6/execute?api-version=2.0&details=true");

			client = HttpClientBuilder.create().build();

			// setup output message by copying JSON body into
			// apache StringEntity object along with content type
			entity = new StringEntity(jsonBody);
			// add HTTP headers
			post.setHeader("Content-type", "application/json");
			post.setHeader("Accept", "application/json");
			// set Authorization header based on the API key
			String apikey = "5VuOY5Yr19bB1t2tBZuWWlagfsQPgEs1BtZOj7X/CdcP9/IkarBh377mYXQe9CEkbXHlqlPQYHRQ+M9SqfN7qw==";
			post.setHeader("Authorization", ("Bearer " + apikey));
			post.setEntity(entity);
			HttpResponse authResponse = client.execute(post);

			String json = EntityUtils.toString(authResponse.getEntity());
			JSONObject jsonObject = new JSONObject(json);
			// JSONArray
			JSONArray jsonobj = jsonObject.getJSONObject("Results").getJSONObject("output1").getJSONObject("value")
					.getJSONArray("Values");
			ClassficationOutput classoutput = new ClassficationOutput();
			String j = jsonobj.get(0).toString();
			String x = j.replaceAll("\"", "");
			String values[] = x.split(",");
			classoutput.setAlgorithm("SVM Algorithm");
			classoutput.setScoredlabel(values[6]);
			classoutput.setScoreprob(values[7].replace(']', ' '));
			return classoutput;

		} catch (Exception e) {

			return null;
		}

	}

}
