package com.neu.assign2;

public class ClassficationOutput {
	
	private String algorithm;
	private String scoredlabel;
	private String scoreprob;
	
	public String getAlgorithm() {
		return algorithm;
	}
	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}
	public String getScoredlabel() {
		return scoredlabel;
	}
	public void setScoredlabel(String scoredlabel) {
		this.scoredlabel = scoredlabel;
	}
	public String getScoreprob() {
		return scoreprob;
	}
	public void setScoreprob(String scoreprob) {
		this.scoreprob = scoreprob;
	}

}
