package com.neu.assign2;

public class RegressionOutput {
	
	private String clusterType;
	private String algorithm;
	private String scoredlabel;
	public String getAlgorithm() {
		return algorithm;
	}
	public void setAlgorithm(String algorithm) {
		this.algorithm = algorithm;
	}
	public String getScoredlabel() {
		return scoredlabel;
	}
	public void setScoredlabel(String scoredlabel) {
		this.scoredlabel = scoredlabel;
	}
	public String getClusterType() {
		return clusterType;
	}
	public void setClusterType(String clusterType) {
		this.clusterType = clusterType;
	}
	

}
