package com.neu.assign2;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RegressionController {

	private static final Logger logger = LoggerFactory.getLogger(RegressionController.class);

	@RequestMapping(value = "/regression.htm", method = RequestMethod.POST)
	public ModelAndView postclassification(HttpServletRequest request, HttpServletResponse response) {
		logger.info("Regression POST method!");
		String grade = request.getParameter("grade");
		String sub_grade = grade+request.getParameter("sub_grade");
		String dti = request.getParameter("dti");
		String fico_range_low = request.getParameter("fico_range_low");
		String fico_range_high = request.getParameter("fico_range_high");
		String term = request.getParameter("term");
		String bc_util = request.getParameter("bc_util");
		String total_pymnt = request.getParameter("total_pymnt");
		String loan_amnt = request.getParameter("loan_amnt");
		String funded_amnt = request.getParameter("funded_amnt");
		String total_pymnt_inv = request.getParameter("total_pymnt_inv");
		String home_ownership = request.getParameter("home_ownership");
		String loan_status = request.getParameter("loan_status");
		String purpose = request.getParameter("purpose");
		String application_type = request.getParameter("application_type");
		String emp_length = request.getParameter("emp_length");
		JSONObject obj = new JSONObject();
		JSONObject inputs = new JSONObject();
		JSONObject input1 = new JSONObject();
		String[] columns = { "Column 0", "int_rate", "sub_grade", "grade", "dti", "fico_range_low", "fico_range_high",
				"term", "bc_util", "total_pymnt", "loan_amnt", "funded_amnt", "total_pymnt_inv", "home_ownership",
				"loan_status", "purpose", "application_type", "emp_length" };
		String[][] values = { { "0", "0", sub_grade, grade, dti, fico_range_low, fico_range_high, term, bc_util,
				total_pymnt, loan_amnt, funded_amnt, total_pymnt_inv, home_ownership, loan_status, purpose,
				application_type, emp_length } };
		input1.put("ColumnNames", columns);
		input1.put("Values", values);
		inputs.put("input1", input1);
		obj.put("Inputs", inputs);
		String json = obj.toString();
		System.out.println(json);
		List<RegressionOutput> regressionList = new ArrayList<RegressionOutput>();
		RegressionOutput manualCluster = manualClusterBasedPrediction(grade, json);
		RegressionOutput noCluster = noClusterBasedPrediction(json);
		RegressionOutput clusterAlgo = clusterAlgoBasedPrediction(json,values);
		regressionList.add(manualCluster);
		regressionList.add(noCluster);
		regressionList.add(clusterAlgo);
		
		RegressionOutput max= new RegressionOutput();
		Double manual=Double.parseDouble(manualCluster.getScoredlabel());
		Double noClus=Double.parseDouble(noCluster.getScoredlabel());
		Double clusAlgo=Double.parseDouble(clusterAlgo.getScoredlabel());
		if(manual>=noClus&&manual>=clusAlgo){
			max=manualCluster;
		}
		else if(noClus>=manual&&noClus>=clusAlgo){
			max=noCluster;
		}
		else if(clusAlgo>=manual&&clusAlgo>=noClus){
			max=clusterAlgo;
		}
		
		ModelAndView mv = new ModelAndView("Regression");
		mv.addObject("regressionList", regressionList);
		mv.addObject("max", max);
		return mv;
	}

	public RegressionOutput manualClusterBasedPrediction(String grade, String jsonBody) {

		HttpPost post = new HttpPost();
		HttpClient client;
		StringEntity entity;
		String apikey = "";

		try {
			RegressionOutput ro = new RegressionOutput();

			if (grade.equalsIgnoreCase("A")) {
				logger.info("A grade called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/83761e93c16946899522ce198bfd2927/execute?api-version=2.0&details=true");
				apikey = "qvxJUbhWGtzdCGfXPUb2IxY1VxwZ0V1dJiKb/bZgEjxowJAKNzbqSGLQvZL0Sf0kAHmrpOXzeLnypl++XNIbCQ==";
				ro.setAlgorithm("Decision Tree Regression");
			} else if (grade.equalsIgnoreCase("B")) {
				logger.info("B grade called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/196269b092be4d08965ed2dd669d5de3/execute?api-version=2.0&details=true");
				apikey = "Q59L7lnp4QJYuE8eSLy94swYkxtB8o7uT8JaEXWehJ8aTfn4u2NjFgKnVb7XcLYbvYPkK4UtUIRgdlbf9yO/fA==";
				ro.setAlgorithm("Neural Network Regression");
			} else if (grade.equalsIgnoreCase("C")) {
				logger.info("C grade called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/62b45b9b25ef415595ac4db047292f03/execute?api-version=2.0&details=true");
				apikey = "NyTO4m5a/rDFBG5/WpJs7LotCdUFRoidXJ/Cf+Y5X642b7NeifWIyaaDI5TXvNrdTMwJkcq7vV4DsPm9fjbQSQ==";
				ro.setAlgorithm("Decision Tree Regression");
			} else if (grade.equalsIgnoreCase("D")) {
				logger.info("D grade called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/b7123f21bfc74d45b805d3c8466e78e5/execute?api-version=2.0&details=true");
				apikey = "SZSrjmNxwO02/JM4Bi6SW6ChK81BVSa82ehgJhKo0Vj7K6Rtstp8pcVv82eNnQrXQAEsQcX4FsRBMGFzPsrSUQ==";
				ro.setAlgorithm("Decision Tree Regression");
			} else if (grade.equalsIgnoreCase("E")) {
				logger.info("E grade called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/6040b3ae85944806bd7bb0d5b7648017/execute?api-version=2.0&details=true");
				apikey = "qpuDnzIG3OGAa4BelClJfEk+dMDKQAPsLe9X/TF1PVoJKG7Rpgr9wc0ONTUUEMc1e9BtYp/gRpaXgMuRpITGtQ==";
				ro.setAlgorithm("Decision Tree Regression");
			} else if (grade.equalsIgnoreCase("F")) {
				logger.info("F grade called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/0e01e305becf43d88e13fa27a62818f1/execute?api-version=2.0&details=true");
				apikey = "c6T/pxs/mHbynptVwPvPiJtwffuqGYdNGBt9u0tQPZl3ZujlI/kwN9gQnF7SSz2AewVoKZZQ2s9erT+bBFsbNg==";
				ro.setAlgorithm("Decision Tree Regression");
			} else if (grade.equalsIgnoreCase("G")) {
				logger.info("G grade called");
				post = new HttpPost(
						"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/2fc20c37f8f7488f89e89d46ac2f20eb/execute?api-version=2.0&details=true");
				apikey = "JnJfffBkApumzbCTZ3fYZoP7ztzSokdNKI1YggauFumb+xrE8IqtsIa0fI7/nAKbggzRzFwjpo9bwwnqmGbVcQ==";
				ro.setAlgorithm("Decision Tree Regression");
			}

			client = HttpClientBuilder.create().build();

			// setup output message by copying JSON body into
			// apache StringEntity object along with content type
			entity = new StringEntity(jsonBody);
			// add HTTP headers
			post.setHeader("Content-type", "application/json");
			post.setHeader("Accept", "application/json");
			// set Authorization header based on the API key

			post.setHeader("Authorization", ("Bearer " + apikey));
			post.setEntity(entity);
			HttpResponse authResponse = client.execute(post);

			String json = EntityUtils.toString(authResponse.getEntity());
			System.out.println(json);
			JSONObject jsonObject = new JSONObject(json);
			JSONArray jsonobj = jsonObject.getJSONObject("Results").getJSONObject("output1").getJSONObject("value")
					.getJSONArray("Values");

			String j = jsonobj.get(0).toString();
			String x = j.replaceAll("\"", "");
			String values[] = x.split(",");
			ro.setScoredlabel(values[17].replace(']', ' '));
			ro.setClusterType("Grade Based");
			return ro;

		} catch (Exception e) {

			return null;
		}
	}

	public RegressionOutput noClusterBasedPrediction(String jsonBody) {
		HttpPost post = new HttpPost();
		HttpClient client;
		StringEntity entity;
		String apikey = "";

		try {
			RegressionOutput ro = new RegressionOutput();

			logger.info("No Cluster grade called");
			post = new HttpPost(
					"https://ussouthcentral.services.azureml.net/workspaces/c449d04c10ac401f97a462b4e47eda20/services/2e13f19dc55542708b16b604d4a84266/execute?api-version=2.0&details=true");
			apikey = "nnxfIvtRLoNZq3hKclCNVH7H/a67XTvs8QHhhtHd8ltj+RWx9IYksVeXUS9tbOkpoSnVXtfn1dS0N7gzYmP/9w==";
			ro.setAlgorithm("Decision Tree Regression");

			client = HttpClientBuilder.create().build();

			// setup output message by copying JSON body into
			// apache StringEntity object along with content type
			entity = new StringEntity(jsonBody);
			// add HTTP headers
			post.setHeader("Content-type", "application/json");
			post.setHeader("Accept", "application/json");
			// set Authorization header based on the API key

			post.setHeader("Authorization", ("Bearer " + apikey));
			post.setEntity(entity);
			HttpResponse authResponse = client.execute(post);

			String json = EntityUtils.toString(authResponse.getEntity());
			System.out.println(json);
			JSONObject jsonObject = new JSONObject(json);
			JSONArray jsonobj = jsonObject.getJSONObject("Results").getJSONObject("output1").getJSONObject("value")
					.getJSONArray("Values");

			String j = jsonobj.get(0).toString();
			String x = j.replaceAll("\"", "");
			String values[] = x.split(",");
			ro.setScoredlabel(values[17].replace(']', ' '));
			ro.setClusterType("No Cluster");
			return ro;

		} catch (Exception e) {

			return null;
		}
	}

	public RegressionOutput clusterAlgoBasedPrediction(String jsonBody,String[][] vals) {
		HttpPost post = new HttpPost();
		HttpClient client;
		StringEntity entity;
		String apikey = "";

		try {
			RegressionOutput ro = new RegressionOutput();

			logger.info("K means Cluster called");
			post = new HttpPost(
					"https://ussouthcentral.services.azureml.net/workspaces/afcd129f3f87473789548c223198f1d4/services/d7548ef403794062ad5b8126834f7ab6/execute?api-version=2.0&details=true");
			apikey = "XbISbJ5GM3yrq+JmRz2N7nXmmzS6Kdcetq7mU9mA51N77VN8UsYS0la+zmah9ndj7vgk33hZMWYUQd75DeMMIw==";

			client = HttpClientBuilder.create().build();

			// setup output message by copying JSON body into
			// apache StringEntity object along with content type
			entity = new StringEntity(jsonBody);
			// add HTTP headers
			post.setHeader("Content-type", "application/json");
			post.setHeader("Accept", "application/json");
			// set Authorization header based on the API key

			post.setHeader("Authorization", ("Bearer " + apikey));
			post.setEntity(entity);
			HttpResponse authResponse = client.execute(post);

			String json = EntityUtils.toString(authResponse.getEntity());
			System.out.println(json);
			JSONObject jsonObject = new JSONObject(json);
			JSONArray jsonobj = jsonObject.getJSONObject("Results").getJSONObject("output1").getJSONObject("value")
					.getJSONArray("Values");

			String j = jsonobj.get(0).toString();
			String x = j.replaceAll("\"", "");
			String values[] = x.split(",");
			String cluster=values[18];
			
			JSONObject obj = new JSONObject();
			JSONObject inputs = new JSONObject();
			JSONObject input1 = new JSONObject();
			String[] columns = { "Column 0", "int_rate", "sub_grade", "grade", "dti", "fico_range_low", "fico_range_high",
					"term", "bc_util", "total_pymnt", "loan_amnt", "funded_amnt", "total_pymnt_inv", "home_ownership",
					"loan_status", "purpose", "application_type", "emp_length" , "Assignments","DistancesToClusterCenter no.0",
			        "DistancesToClusterCenter no.1","DistancesToClusterCenter no.2"};
			String[][] val = { {vals[0][0], vals[0][1], vals[0][2], vals[0][3], vals[0][4], vals[0][5], vals[0][6], vals[0][7], vals[0][8],
				vals[0][9], vals[0][10], vals[0][11], vals[0][12], vals[0][13], vals[0][14], vals[0][15],
				vals[0][16], vals[0][17],cluster,"","","" } };
			input1.put("ColumnNames", columns);
			input1.put("Values", val);
			inputs.put("input1", input1);
			obj.put("Inputs", inputs);
			String jsonString = obj.toString();
			System.out.println(jsonString);
			ro=runPrediction(cluster, jsonString);
			ro.setClusterType("K-Means Cluster");
			return ro;

		} catch (Exception e) {

			return null;
		}
	}
	
	public RegressionOutput runPrediction(String cluster, String jsonBody){
		HttpPost post = new HttpPost();
		HttpClient client;
		StringEntity entity;
		String apikey = "";
		try{
			RegressionOutput ro = new RegressionOutput();
		if (cluster.equalsIgnoreCase("0")) {
			logger.info("Cluster 1");
			post = new HttpPost(
					"https://ussouthcentral.services.azureml.net/workspaces/afcd129f3f87473789548c223198f1d4/services/b4ec2281c51048858bc4474ffe2a4282/execute?api-version=2.0&details=true");
			apikey = "70aERUfhpIQjHOgDkBXJJn2sJ/FQPzFDyHD4i0qCJN3y3SqcQhQqhQKAdWWDXs5ODspQQ/lpcVlgggkF0v4zhA==";
			ro.setAlgorithm("Decision Forest Regression");
		} else if (cluster.equalsIgnoreCase("1")) {
			logger.info("Cluster 2");
			post = new HttpPost(
					"https://ussouthcentral.services.azureml.net/workspaces/afcd129f3f87473789548c223198f1d4/services/f326cef757c54115b05697db9c24ae45/execute?api-version=2.0&details=true");
			apikey = "VF3MnTbkxqCTsoT0q05kRXj4ZCrKq0Ed1UKw/T/DsPO7b1IRFGGVfvaon+yKXRSm0lfG0svj0z795wZlhXCKkg==";
			ro.setAlgorithm("Neural Network Regression");
		} else if (cluster.equalsIgnoreCase("2")) {
			logger.info("Cluster 3");
			post = new HttpPost(
					"https://ussouthcentral.services.azureml.net/workspaces/afcd129f3f87473789548c223198f1d4/services/67a17d8d01b34268bb98289d971ed370/execute?api-version=2.0&details=true");
			apikey = "ZuGJgGtYrlvbWB0Y6OB1Bc8gqRMcHjhQQO/ikI0UVR8ytrJyvv9FZu+UuHdpDo5VjYoF7EbJ2UsOBd7tEqXhtw==";
			ro.setAlgorithm("Neural Network Regression");
		} 

		client = HttpClientBuilder.create().build();

		// setup output message by copying JSON body into
		// apache StringEntity object along with content type
		entity = new StringEntity(jsonBody);
		// add HTTP headers
		post.setHeader("Content-type", "application/json");
		post.setHeader("Accept", "application/json");
		// set Authorization header based on the API key

		post.setHeader("Authorization", ("Bearer " + apikey));
		post.setEntity(entity);
		HttpResponse authResponse = client.execute(post);

		String json = EntityUtils.toString(authResponse.getEntity());
		System.out.println(json);
		JSONObject jsonObject = new JSONObject(json);
		JSONArray jsonobj = jsonObject.getJSONObject("Results").getJSONObject("output1").getJSONObject("value")
				.getJSONArray("Values");

		String j = jsonobj.get(0).toString();
		String x = j.replaceAll("\"", "");
		String values[] = x.split(",");
		ro.setScoredlabel(values[17].replace(']', ' '));
		return ro;

	} catch (Exception e) {

		return null;
	}
	}

}
